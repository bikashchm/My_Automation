package com.Linqx_BackEnd.runner;

import org.testng.annotations.Listeners; 
import org.testng.annotations.Test;
import com.aventstack.extentreports.testng.listener.ExtentITestListenerClassAdapter;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
    features = "src/test/resources/features",
    glue = "stepDefinitions",
    publish=true,
    plugin={"pretty","html:target/CucumberReports/CucumberReport.html"},
    monochrome=true,
    tags = "@Feature_CreateDistrict or @feature_CreateProppant or @feature_CreateJob or @feature_Day1ActivityLog or @feature_SetupProppant or @feature_ChemicalSetupor or @feature_AddEmailVendor or @feature_proppant_delivery or @feature_run_order or @Chemical_deliverytracking"
)


@Listeners({ExtentITestListenerClassAdapter.class})
public class TestRunner extends AbstractTestNGCucumberTests {

    @Test(priority = 1)
    public void runDistrictFeature() {
        runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/CreateDistrict.feature");
    }
    
  @Test(priority = 2)
  public void runProppantFeature() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/CreateProppant.feature");
  }
 
  @Test(priority = 3)
  public void CreateJob() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/CreateJob.feature");
  }
  
  @Test(priority = 4)
  public void Day1ActivityLog() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/Day1ActivityLog.feature");
  }

  @Test(priority = 5)
  public void runProppantSetUpFeature() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/SetupPropantwithdata.feature");
  }
  
  @Test(priority = 6)
  public void runProppantDelieveryFeature() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/CreateProppantDelivery.feature");
  }
  
  
  @Test(priority = 7)
  public void runChemicalDelieveryTrackingFeature() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/ChemicalDelieveryTracking.feature");
	}	
  @Test(priority = 8)
  public void runChemicalInventory() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/ChemicalInventory.feature");
	}
  
  @Test(priority = 9)
  public void Fieldticket() {
      runCucumberFeature("src/test/resources/com/Linqx_BackEnd/features/Fieldticketsgeneration.feature");
	}	
	
    private void runCucumberFeature(String featurePath) {
        io.cucumber.core.cli.Main.run(new String[]{featurePath}, Thread.currentThread().getContextClassLoader());
    }
}




