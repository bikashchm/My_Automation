package com.Linqx_BackEnd.utils;

public class FilePath {
 public static String getConfigPropertyFilePath() {
	 return "/src/test/resources/com/Linqx_BackEnd/config/config.properties";
 }
}
