package com.Linqx_BackEnd.utils;

import java.io.File; 
import java.util.Date;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class ExtentManager {
	
	public static ExtentReports extent;
	public static String path;
	
	public static ExtentReports createInstance() {
		
		String fileNames= getReportName();
		String directory = System.getProperty("user.dir")+"\\CucumberReports\\";
		new File(directory).mkdir();
		path= directory+fileNames;
		
		ExtentSparkReporter extentSpartReporter=new ExtentSparkReporter(path);
		extentSpartReporter.config().setReportName("Report: Automation Test Results");
		extentSpartReporter.config().setDocumentTitle("Title : Automation Testing");
		extentSpartReporter.config().setTheme(Theme.STANDARD);
		extentSpartReporter.config().setEncoding("utf-8");
		extent=new ExtentReports();
		extent.attachReporter(extentSpartReporter);
		extent.setSystemInfo("Organization", "WTT");// General Information related to application
		return extent;
	}
		//To get the latest Date and Time for setting file name
	    public static String getReportName() {
		Date d=new Date ();
		String fileName="AutomationReport"+d.toString().replace(":", "_").replace("","_")+".html";
		return fileName;
	}
	
}
