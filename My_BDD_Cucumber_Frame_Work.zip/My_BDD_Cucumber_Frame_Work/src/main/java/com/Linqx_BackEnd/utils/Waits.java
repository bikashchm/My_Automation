package com.Linqx_BackEnd.utils;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waits { 
		
	public static void waitForElementToBeVisible(WebDriver driver,int time,By locater) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.visibilityOfElementLocated(locater));
	}
	
	public static void waitForElementToBeVisible(WebDriver driver,int time,WebElement element) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.visibilityOf(element));
	}
	
	public static void waitForAllElementToBeVisible(WebDriver driver,int time,By element) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(element));
	}
	
	public static void waitForTextToBe(WebDriver driver,int time,By element,String text) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.textToBePresentInElementLocated(element,text));
	}
	
	public static void waitForElementToBeClickable(WebDriver driver,int time,WebElement element) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void waitForElementToBeInvisible(WebDriver driver,int time,By element) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.invisibilityOfElementLocated(element));
	}
	
	public static void waitForPresenceOf(WebDriver driver,int time,By element) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.presenceOfElementLocated(element));
	}
	
	public static void textToBe(WebDriver driver,int time,WebElement element,String text) {
		new WebDriverWait(driver,Duration.ofSeconds(time)).until(ExpectedConditions.textToBePresentInElement(element,text));
	}
	
	
	
}
